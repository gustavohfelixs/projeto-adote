package br.com.adote;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdoteApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdoteApplication.class, args);
	}

}
