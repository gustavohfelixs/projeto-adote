package br.com.adote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
